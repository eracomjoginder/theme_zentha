module.exports = {

"[project]/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/favicon--route-entry.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "GET": ()=>GET,
    "dynamic": ()=>dynamic
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("AAABAAEAIB8AAAEAIAAkEAAAFgAAACgAAAAgAAAAPgAAAAEAIAAAAAAAgA8AACMuAAAjLgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoBvJoKAbyaCgK8mgoCvJoKAryaCgK8mgoCvJoKAryaCgK8mgoCvJoKAryaCgK8mgoCvJoKAryaCgG8mgoBvJoKAbyaCgC8mgoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoBvJoKAryaCgO8mgoDvJoKBLyaCgW8mgoFvJoKBbyaCgW8mgoFvJoKBbyaCgW8mgoFvJoKBbyaCgW8mgoEvJoKBLyaCgO8mgoCvJoKAryaCgG8mgoAvJoKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALyaCgC8mgoAvJoKAbyaCgK8mgoEvJoKBbyaCge8mgoIvJoKCbyaCgq8mgoKvJoKC7uZCgu7mQoKu5kKCryaCgq8mgoKvJoKCryaCgm8mgoIvJoKB7yaCgW8mgoEvJoKAryaCgG8mgoAvJoKAAAAAAAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoCu5kKBNGpAwXkuQUH2rIICtSuCA3QqggPzKYIEMSgBxG8mQISv5sCEsKfBRO9mwMSvpwFEcCcBhDCngcPxqEHDsmkBwzLpQcK0KgEB7+cCQa8mgoEvJoKAryaCgG8mgoAvJoKAAAAAAAAAAAAAAAAALyaCgC8mgoAvJoKAbyaCAPAnxkHincuIVhMFC1cThEyZFQQN2xaEDyDbRBCr5IUSdy6M07ZuDlR064ZS924IEnNqxtEupsZPaaLGDiUfBQ2inMPM412ETCFcx0oo4kWDb+cCAa8mgoEvJoKAryaCgG8mgoAvJoKAAAAAAC8mgoAvJoKALyaCgG8mgoCvpsIBM6rGAhmWzOBPjki5hsbEOYcGw/oNTEU6mBUHeyTfivuvaE877ebL/CmjB/ql4Ec631sFepoWhDoWk8O5ldOFeZYUSPlUE4s5T8+J8h3aSQm0qoBB7yaCgW8mgoCvJoKAbyaCgC8mgoAAAAAALyaCgC8mgoAvJoKAbyaCgK8mgoE2rAABm5hKSxIQyrQPzol/y4qFv8uKxP/QDoa/1BHGf9dUhj/W1EW/1JJE/9HQBL/RkAZ/09MK/9cXET/XV9R/0ZLRP8iJiT/JCYd3ntrIinPqAMJvJoKBryaCgO8mgoBvJoKALyaCgAAAAAAAAAAALyaCgC8mgoAvJoKAryaCgS7mQoI4rcDC2dcKVZBPibuRD8p/yonGf8YGhX/JScd/y0tGv85NyD/UVE8/2hrW/9scWf/ZWtm/1BWU/80Ojf/GBwZ/w8SD/8lKB7efGshKc2nBAq8mgoGvJoKA7yaCgG8mgoAvJoKAAAAAAAAAAAAvJoKALyaCgC8mgoBvJoKBLyaCge8mggN0KwUFW1jLIg7OyT8Pz4s/zo2I/8eIBr/Jisp/3R6dv+Nk5D9bHFs8UVJQu4sLynuICMd7B8jHe0vNDD7MTc0/yUnHt15ZyEpzqgDCbyaCga8mgoDvJoKAbyaCgC8mgoAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoDvJoKBryaCgu+mwURwaQmJ3BnLbZDQyb/Q0Qx/0ZDLv8sKyD/UlhV/1FUSPFpXSF6dGMUU3NkHU93aihJeW4wRZWZiIWCi4nsODox3m1cGybTrAIIvJoKBbyaCgO8mgoBvJoKALyaCgAAAAAAAAAAALyaCgC8mgoAvJoKAbyaCgK8mgoEvJoKCLyaCg7AnAIUu6M1RIl6Md5ZVir/SEs2/01MOf89Oyv/IiET/19VHrTLqiA5xJ8DJsahBiDIogIaxKERF6CiiU9nal6ibWAmItetAAa8mgoEvJoKAryaCgG8mgoAvJoKAAAAAAAAAAAAAAAAALyaCgC8mgoAvJoKAbyaCgO8mgoGvJoKCruZCRHKpgob1blHequVM/h0ayz/T1E5/01RRP9PTTP/koZG/OHMgZrHpicru5gGHryaChi8mgkSxpsFDKaZUxaljy0MwJwFBLyaCgO8mgoBvJoKALyaCgAAAAAAAAAAAAAAAAAAAAAAvJoKALyaCgC8mgoBvJoKAryaCgS8mgoHvJoKDcCeBBTXukFE3L5V55aBJv88OBn/Jige/y8zLf9WVDr/r6Bp9uLKhnm7mAYcvJoKFryaCg+8mgoLwpwFB8CcCQW8mgoDvJoKAryaCgG8mgoAvJoKAAAAAAAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoCvJoKA7yaCga8mgoKvp0LEM+zNCLfwmeQnYc8+DgxD/8eHAn/IiAK/y4rEP9UTCP/q5ZI3tu5LEu7mAMWvJoKD7yaCgq8mgoGvJoKA7yaCgK8mgoBvJoKALyaCgAAAAAAAAAAAAAAAAAAAAAAvJoKALyaCgC8mgoBvJoKAsCeCQPOrQYDvZsKB7yaCgm9mwwOwqENFcGlHyaQg0Kba2Ey/EI8Gv83MxD/W08T/4hwGv+wkCf/2bYspOXCDzK8mgoSvJoKC7yaCga8mgoDvJoKAbyaCgG8mgoAvJoKAAAAAAAAAAAAAAAAALyaCgC8mgoAvJoKAbyaCgLFoAcDinUZCnVkHBvWrwgIv5wIC7yaCg+9mwsUxKMOG62YITBsZzmkWVY6/EVBJf8qKBH/NTAP/1NIEv+GcR3dzKsgVNWwBh29mwoOvJoKCLyaCgS8mgoCvJoKAbyaCgC8mgoAAAAAAAAAAAAAAAAAvJoKALyaCgC8mgoBvJoKA+O3AARhViMePzodsWpbG2i8mhQX0KkDEMqkCBXIpAoazagMIa6SFTVQSyq0SUo7/1JQNv8sKhT/IB4L/zs1D/94ZhyvyaYVJ8OgBxO7mgoKvJoKBbyaCgK8mgoBvJoKALyaCgAAAAAAAAAAALyaCgC8mgoAvJoKAbyaCgK8mgoE2rACBmhbISIkJhzaR0Eb+XFhIaeAcCdKcWITO3BfDT54ZQtBln0MQ7aXIJJMRRr/OT45/1lZR/86Nx//Hx0K/zkzDvl8aRx51K0PFLuaCQ28mgoHvJoKA7yaCgG8mgoAvJoKAAAAAAAAAAAAvJoKALyaCgC8mgoBvJoKAryaCgXUrAMIbmAgJR8iHNs1ODD/bnJj/0FEOfAVFgzoGBcH5zgyCeV8aBLlvJ0i9HNmI/8XGhP/LTMu/1xgV/9MSzP/JiQN/0A4EOSPdyBG0qsFDbyaCgm8mgoEvJoKAryaCgC8mgoAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoCvJoKBdKqBAhvYB4mIyYf21VdXf9HTk3/DhAM/xkYCf8/ORj/dGg1/6GUXv+2sYr/tbis/5ablv9lamT/TFJO/2huaf9hYU7/NjMW/0g/ErqihxseyKMGCLyaCgW8mgoCvJoKAbyaCgC8mgoAAAAAALyaCgC8mgoAvJoKAbyaCgK8mgoF1KwDCGlaGiYyNi/cOj87/yEhFf9DQCr/c29V/5mYhP+ws6j/vMK9/8XLx//L0Mv/z9PN/8zPxf+9u6X/o5p0/4eGbf9na1z/SUYp/FNIGH3LpxEKv5wJBbyaCgK8mgoBvJoKALyaCgAAAAAAvJoKALyaCgC8mgoBvJoKAryaCgTTqwIHb2EhIERFNMBVVEDleXpn4pOXiOGgpJjip6yd47G0nuTCwqPm09Cq69/Zr/Xk2qn0386M6sq2bOWglFnjhIVr4Z+oo+GYoJniZ2VKwXFkIiP6xQADvJoKAryaCgG8mgoAvJoKAAAAAAAAAAAAvJoKALyaCgC8mgoBvJoKA76bCQatjxMLjX88JKugYi+3q2gxualXNMKuSTvOtkBD2r87TOPHOVPszTNj89M3gPPROHjivyRayKoZTL6oN0HOwG03zMKBL8bCkyminncjkX0kC8agAwO8mgoBvJoKALyaCgAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoCvJoKBL6bCQbKogEIw5oACsGaAA3IoQAR0qsAFtu0AB3huQAj5LwAKOa+ACvnvgAu5b0ALOO8ACfhuQIi2bIAGs6mABPEmwANvZEACMeZAAXDnggEu5oKAryaCgG8mgoAvJoKAAAAAAAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoCvJoKBLyaCgW8mgoHvZsKCMKfCQrKpggN0q4HD9mzBhLdtwUU37kFFt+5BRbeuAUV27YFFNexBhHQrAcOyKUIC8CeCQi8mgoGvJoKBLyaCgK8mgoBvJoKAbyaCgC8mgoAAAAAAAAAAAAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoCvJoKAryaCgO8mgoEvZsKBcCeCgXFogkGyqcIB86qBwfQrAcI0a0HCNCrBwjNqQcHyaYIBsShCQW/nQoEvJoKBLyaCgO8mgoCvJoKAbyaCgG8mgoAvJoKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8mgoAvJoKALyaCgG8mgoBvJoKAbyaCgK8mgoCu5kKAruZCgK7mQoCupgKArqYCgK6mAoCupgKArqYCgK7mQoCu5kKAruaCgK8mgoBvJoKAbyaCgG8mgoAvJoKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALyaCgC8mgoAvJoKAbyaCgG8mgoBvJoKAbyaCgG8mgoBvJoKAbyaCgC8mgoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///////////gAAf/gAAB/4AAAP8AAAB/AAAAPgAAAD4AAAA/AAAAPwAAAD8AAAA/AAAAP4AAAH+AAAB/gAAA/wAAAP4AAAD+AAAA/AAAAPwAAAD8AAAAfAAAAHwAAAB+AAAA/gAAAP8AAAD/gAAB/8AAB///Af//////8=", 'base64');
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__80bb4c51._.js.map