(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_3975fb29._.js",
  "static/chunks/node_modules_next_573a9b57._.js"
],
    source: "dynamic"
});
